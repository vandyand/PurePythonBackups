
##########################################
# This script practices communication with
# an AWS S3 file
##########################################

import boto3
#import uuid

s3_client = boto3.client('s3',
                      region_name='us-east-2',
                      aws_access_key_id='AKIAIZAO7MTXDXNDINPQ',
                      aws_secret_access_key='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')
s3_resource = boto3.resource('s3',
                      region_name='us-east-2',
                      aws_access_key_id='AKIAIZAO7MTXDXNDINPQ',
                      aws_secret_access_key='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')

bucket = 'juliettbucket'

def get_s3_csv_file(filename):
    obj = s3_client.get_object(Bucket=bucket, Key=filename)
    
    csv_vals = obj['Body'].read().decode('utf-8').split(',') # Get list of csv data (doesn't clean newlines...)
    
    return(csv_vals)

def get_s3_config_file(filename):
    obj = s3_client.get_object(Bucket=bucket, Key=filename)
    
    config_vars = obj['Body'].read().decode('utf-8').split('\r\n') # Get list
    
    config_vars = dict([ x.split(' = ') for x in config_vars ]) # Turn into dict
    
    return(config_vars)

def upload_s3_file():
    s3_resource.Bucket(Bucket=bucket).upload_file('ea_params.csv','ea_params.csv')
 
def put_s3_file(body):
    s3_client.put_object(Body=body, Bucket=bucket, Key='upload_test.csv')



