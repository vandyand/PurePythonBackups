

#------------------------------------------------------------------------------
#JuliettLiveTrader in python is for an AWS Lambda implementation of the
#Juliett trading strategy (which is just using long and short back one and two)
#to make long/short trades.
#------------------------------------------------------------------------------


import json
import time

import oandapyV20
import oandapyV20.endpoints.accounts as accounts
import oandapyV20.endpoints.orders as orders
import oandapyV20.endpoints.positions as positions
#import oandapyV20.endpoints.pricing as pricing
import oandapyV20.endpoints.instruments as instruments

import boto3
import logging

def lambda_handler(event,context):
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    a = algo()
    logger.info(a.log_message)
    
    a.run_business_logic()
    logger.info(a.log_message)
    
    # Build return dictionary
    ret_dict = { 'body': 'test body content',
                 'ev': event }
    
    # Return binary return dictionary
    ret = json.dumps(ret_dict)
    
    return ret

class algo:
    # String for logging messages
    log_message = ''
    
    #accountID = '101-001-5729740-009' # PythonTest account
    accountID = '' # ClassDemo account
    access_token = '' # Oanda api key
    oanda_client = ''
    
    # Access to s3 file
    s3_client = ''
    
    instrument = ''
    granularity = ''
    back_candles = ''
    
    ea_params = []
    Long_Back_1 = 0
    Long_Back_2 = 0
    Short_Back_1 = 0
    Short_Back_2 = 0
    lots = 0
    
    LongCond = False
    ShortCond = False
    
    
    config_filename = 'config.txt'
    ea_params_filename = 'ea_params.csv'
    
    def __init__(self):
        # Access to s3 file
        self.s3_client = boto3.client('s3',
                region_name='us-east-2',
                aws_access_key_id='AKIAIZAO7MTXDXNDINPQ',
                aws_secret_access_key='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')
        
        config_vars = self.get_s3_config_file()
        
        # OANDA API access
        #accountID = '101-001-5729740-009' # PythonTest account
        self.accountID = config_vars['accountID'] # OANDA ClassDemo account
        self.access_token = config_vars['access_token'] # OANDA access token
        self.oanda_client = oandapyV20.API(access_token=self.access_token)
        
        self.instrument = config_vars['instrument']
        self.granularity = config_vars['granularity']
        self.back_candles = int(config_vars['back_candles'])
        
        self.get_ea_params()
        
        self.lots = int(config_vars['lots'])
        
        self.log_message += 'Algo class initiallized!\n'
        print('Algo class initiallized!')
        
    def get_s3_config_file(self,filename=None):
        if filename is None:
            filename = self.config_filename
        obj = self.s3_client.get_object(Bucket='juliettbucket', Key=filename)
        config_vars = obj['Body'].read().decode('utf-8').split('\r\n') # Get list
        config_vars = dict([ x.split(' = ') for x in config_vars ]) # Turn into dict
        return(config_vars) # return dict of key value pairs
    
    def get_ea_params(self,filename=None):
        if filename is None:
            filename = self.ea_params_filename
        self.ea_params = self.get_s3_file('juliettbucket',filename)
        self.Long_Back_1,self.Long_Back_2,self.Short_Back_1,self.Short_Back_2 = self.ea_params
    
    def get_s3_file(self,bucket,filename):
        obj = self.s3_client.get_object(Bucket=bucket, Key=filename)
        ea_params = obj['Body'].read().decode('utf-8').split(',')
        ea_params = [ int(x) for x in ea_params ]
        return(ea_params)    
    
    def open_trade(self,data):
        r = orders.OrderCreate(accountID=self.accountID, data=data)
        self.oanda_client.request(r)
        print('Trade opened!')
        self.log_message += 'Trade opened!\n'
        self.get_position_info()
    
    def close_position(self,data,instrument=None):
        if instrument is None:
            instrument = self.instrument
        r = positions.PositionClose(accountID=self.accountID,instrument=self.instrument,data=data)
        self.oanda_client.request(r)
        print('Position closed!')
        self.log_message += 'Position closed!\n'
        self.get_position_info()
    
    def close_long_position(self,instrument=None):
        if instrument is None:
            instrument = self.instrument
        data = {"longUnits":"ALL"}
        self.close_position(data=data,instrument=instrument)
        
    def close_short_position(self,instrument=None):
        if instrument is None:
            instrument = self.instrument
        data = {"shortUnits":"ALL"}
        self.close_position(data=data,instrument=instrument)
    
    
    def get_position_info(self):
        r = accounts.AccountDetails(accountID=self.accountID)
        res = self.oanda_client.request(r)
        for i in range(len(res['account']['trades'])):
            message = ("trade id: " + res['account']['trades'][i]['id'] +
                  ", instrument: " + res['account']['trades'][i]['instrument'] +
                  ", units: " + res['account']['trades'][i]['currentUnits'])
            print(message)
            self.log_message += (message + '\n')
        message = ('num open trades: ' + str(len(res['account']['trades'])) + 
                  '\naccount NAV: ' + res['account']['NAV'])
        print(message)
        self.log_message += message
    

    #------------------------------------------------
    #Streaming tick data
    #------------------------------------------------
    #def get_streaming_data(params):
    #    r = pricing.PricingStream(accountID=accountID,params=params)
    #    res = oanda_client.request(r)
    #    print(res)
    #    
    #    r = pricing.PricingStream(accountID=accountID, params=params)
    #    rv = oanda_client.request(r)
    #    maxrecs = 100
    #    d = {}
    #    for ticks in rv:
    #        
    #        try:
    #            if ticks['instrument'] not in d.keys():
    #                d[ticks['instrument']] = 1
    #                
    #            else:
    #                d[ticks['instrument']] += 1
    #            maxrecs -= 1
    #        except:
    #            pass
    #        print(d)
    #        if maxrecs == 0:
    #            r.terminate("maxrecs records received")
    #params = {"instruments": "EUR_USD,EUR_JPY,AUD_USD,USD_JPY,GBP_USD,AUD_JPY"}
    #get_streaming_data(params)
    
    
    def get_candles_baseFunc(self,instrument,granularity,count):
        params = {"count": count,"granularity": granularity}
        r = instruments.InstrumentsCandles(instrument=instrument,params=params)
        res = self.oanda_client.request(r)
        return res['candles']
    
    def get_back_candles(self,instrument,granularity,count):
        res = self.get_candles_baseFunc(instrument,granularity,count)
        open_prices = [ float(x['mid']['o']) for x in res ][::-1]
        return(open_prices)
        
    def new_bar(self,granularity,list_var):
        b = list_var
        b.append(self.get_candles_baseFunc('EUR_USD',self.granularity,1)[0]['time'])
        if b[-1] != b[0]:
            b = list(filter(lambda x: x != b[0], b))
            print('New bar!')
            return True,b
        else:
            return False,b
        
        
    def check_open_position(self,instrument=None):
        if instrument is None:
            instrument = self.instrument
        try:
            r = positions.OpenPositions(accountID=self.accountID)
            res = self.oanda_client.request(r)['positions']
            if res:
                for i in res:
                    if i['instrument'] == instrument:
                        if i['long']['units'] == '0':
                            return 'short'
                        else:
                            return 'long'
                    else:
                        return 'none'
            else:
                return 'none'
        except:
            return 'none'
      
    
    def run_business_logic(self):
        open_prices = self.get_back_candles(self.instrument,self.granularity,self.back_candles)
        
        if open_prices[self.Long_Back_1] > open_prices[self.Long_Back_2]:
            LongCond = True
            print('LongCond = True')
            self.log_message += 'LongCond = True'
        else:
            LongCond = False
            print('LongCond = False')
            self.log_message += 'LongCond = False'
        if open_prices[self.Short_Back_1] > open_prices[self.Short_Back_2]:
            ShortCond = True
            print('ShortCond = True')
            self.log_message += 'ShortCond = True'
        else:
            ShortCond = False
            print('ShortCond = False')
            self.log_message += 'ShortCond = False'
        
        current_position = self.check_open_position() # Either 'long', 'short' or 'none'
        
        if current_position!='none':
            if current_position=='long' and not LongCond:
                self.close_long_position()
            elif current_position=='short' and not ShortCond:
                self.close_short_position()
            time.sleep(2) # Wait for close orders to process before proceeding
        
        if LongCond!=ShortCond and self.check_open_position()=='none':
            if LongCond:
                units = str(self.lots * 100000)
            elif ShortCond:
                units = str(self.lots * -100000)
            data = {"order":{"instrument":self.instrument,"units":units,"type":"MARKET"}}
            self.open_trade(data)

    def run(self):
        new_bar_holder = []
        while(True):
            try:
                results = self.new_bar(self.granularity,new_bar_holder)
                new_bar_holder = results[1]
                if results[0]:
                    self.run_business_logic()
            except:
                pass
            time.sleep(5)
        
    
    



