
import boto3
import json

client = boto3.client('lambda',
                      region_name='us-east-2',
                      aws_access_key_id='AKIAIZAO7MTXDXNDINPQ',
                      aws_secret_access_key='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')

payload = '1,2,3,5'
payload = json.dumps(payload)

arn = 'arn:aws:lambda:us-east-2:065445439437:function:test_algo_trader'
#arn = 'arn:aws:lambda:us-east-2:065445439437:function:my_func'

response = client.invoke(FunctionName=arn,
                         Payload=payload)

print(response['Payload'].read())




